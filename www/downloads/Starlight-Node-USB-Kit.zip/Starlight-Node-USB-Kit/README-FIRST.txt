Starlight Node USB Kit (LAB / NODE BUILDERS ONLY)
================================================
DO NOT use this package on a normal staff Windows laptop for Fabric VPN.

Ben / staff Windows PC should use:
  Fabric-Client-Windows.zip  (Fabric Client Windows v1.2+)

This USB kit is for building Starlight Fabric *nodes* (boot media, lab nodes).
If you installed this by mistake on Windows, ignore it and download Fabric-Client-Windows instead.
