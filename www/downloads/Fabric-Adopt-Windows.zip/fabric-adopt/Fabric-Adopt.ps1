#Requires -Version 5.1
<#
.SYNOPSIS
  Kaditech Project Starlight - Fabric Windows Adopter (consent-based)
.DESCRIPTION
  Opt-in Fabric nano-receptor for Windows client nodes.
  - Asks for explicit consent (no silent install)
  - Inventories host for Help / recovery jobs
  - Registers heartbeat with Fabric registry on TA
  - Optional: open LAN-only recovery ports for lab (192.168.1.0/24)
  Test case: JOB-ARISE-2026-0803 (arisefront)
#>
param(
  [string]$Registry = "http://192.168.1.198:3055",
  [string]$JobId = "JOB-ARISE-2026-0803",
  [string]$NodeName = "",
  [switch]$UnattendedConsent,  # only if user already approved via Run-Adopt.cmd
  [switch]$OpenLabAccess,      # create LAN-only firewall rules + ensure RDP/WinRM
  [int]$HeartbeatSeconds = 20
)

$ErrorActionPreference = "Continue"
$AgentVersion = "fabric-windows-adopt/1.0"
$InstallDir = Join-Path $env:ProgramData "Kaditech\FabricAdopt"
$LogFile = Join-Path $InstallDir "adopt.log"
$StateFile = Join-Path $InstallDir "state.json"

function Write-Log($msg) {
  $line = "[{0}] {1}" -f (Get-Date -Format o), $msg
  try {
    New-Item -ItemType Directory -Force -Path $InstallDir | Out-Null
    Add-Content -Path $LogFile -Value $line
  } catch {}
  Write-Host $line
}

function Show-Consent {
  $title = "Kaditech Fabric Adoption"
  $body = @"
Project Starlight - Fabric opt-in (NOT silent spyware)

This will:
1) Inventory this PC (name, OS, disk, software summary, RDP status)
2) Register a Fabric heartbeat with the Kaditech lab (TA on your LAN)
3) Log progress for job $JobId so Thomas/R2 can help recovery
4) Optionally open recovery ports ONLY to LAN 192.168.1.0/24 (if you approve next)

You can revoke by running: Uninstall-Fabric-Adopt.ps1

Do you approve adoption on this computer?
"@
  if ($UnattendedConsent) { return $true }
  try {
    Add-Type -AssemblyName System.Windows.Forms | Out-Null
    $r = [System.Windows.Forms.MessageBox]::Show($body, $title, "YesNo", "Question")
    return ($r -eq "Yes")
  } catch {
    Write-Host $body
    $a = Read-Host "Type YES to approve"
    return ($a -eq "YES")
  }
}

function Get-Inventory {
  $cs = Get-CimInstance Win32_ComputerSystem
  $os = Get-CimInstance Win32_OperatingSystem
  $cpu = @(Get-CimInstance Win32_Processor)
  $disk = Get-CimInstance Win32_LogicalDisk -Filter "DriveType=3" | ForEach-Object {
    [pscustomobject]@{
      device = $_.DeviceID
      free_gb = [math]::Round(($_.FreeSpace/1GB),2)
      size_gb = [math]::Round(($_.Size/1GB),2)
    }
  }
  $memTotal = [int]($os.TotalVisibleMemorySize / 1024)
  $memFree = [int]($os.FreePhysicalMemory / 1024)
  $apps = @()
  try {
    $paths = @(
      "HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*",
      "HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*",
      "HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*"
    )
    $apps = Get-ItemProperty $paths -ErrorAction SilentlyContinue |
      Where-Object { $_.DisplayName } |
      Select-Object -ExpandProperty DisplayName -Unique |
      Sort-Object |
      Select-Object -First 80
  } catch {}

  $rdp = $false
  try {
    $rdp = (Get-ItemProperty "HKLM:\System\CurrentControlSet\Control\Terminal Server").fDenyTSConnections -eq 0
  } catch {}

  $fw = @{}
  try {
    Get-NetFirewallProfile | ForEach-Object { $fw[$_.Name] = $_.Enabled }
  } catch {}

  $mcafee = $apps | Where-Object { $_ -match "McAfee|Trellix" }

  return [ordered]@{
    hostname = $env:COMPUTERNAME
    domain = $cs.Domain
    user = $env:USERNAME
    manufacturer = $cs.Manufacturer
    model = $cs.Model
    platform = $os.Caption + " " + $os.Version
    os_build = $os.BuildNumber
    cpu_count = ($cpu | Measure-Object -Property NumberOfLogicalProcessors -Sum).Sum
    cpu_name = ($cpu | Select-Object -First 1).Name
    mem_total_mb = $memTotal
    mem_avail_mb = $memFree
    load1 = 0
    disk_free_gb = [math]::Round((($disk | Measure-Object free_gb -Sum).Sum),2)
    disks = $disk
    net_ok = $true
    rdp_enabled = $rdp
    firewall_profiles = $fw
    mcafee_like = @($mcafee)
    software_sample = @($apps)
    ts = [DateTimeOffset]::UtcNow.ToUnixTimeSeconds()
    uname = $os.Caption
  }
}

function Get-Efficiency($inv) {
  $cpu = [double]($inv.cpu_count); if ($cpu -lt 1) { $cpu = 1 }
  $ram = [double]($inv.mem_total_mb)
  $headroom = 0.7
  $ram_ok = [math]::Min(1.0, $ram / 4096.0)
  $net = 1.0
  $disk = if ([double]$inv.disk_free_gb -gt 2) { 1.0 } else { 0.5 }
  $base = 0.35*$headroom + 0.25*[math]::Min(1.0, $cpu/4.0) + 0.2*$ram_ok + 0.1*$net + 0.1*$disk
  return [math]::Round([math]::Min(1.0, [math]::Max(0.0, $base)), 4)
}

function Post-Json($url, $obj) {
  $json = $obj | ConvertTo-Json -Depth 8 -Compress
  try {
    $resp = Invoke-RestMethod -Uri $url -Method Post -Body $json -ContentType "application/json; charset=utf-8" -TimeoutSec 12
    return @{ ok = $true; body = $resp }
  } catch {
    Write-Log "POST fail $url :: $($_.Exception.Message)"
    return @{ ok = $false; error = $_.Exception.Message }
  }
}

function Register-Fabric($inv) {
  $name = if ($NodeName) { $NodeName } else { "win-$($inv.hostname)" }
  $eff = Get-Efficiency $inv
  $payload = [ordered]@{
    name = $name
    role = "edge"
    inventory = $inv
    efficiency = $eff
    heartbeat_hz = 0.05
    agent = $AgentVersion
    gci = $true
    layer = "experience_time"
    job_id = $JobId
    consent = $true
  }
  $r = Post-Json ($Registry.TrimEnd("/") + "/fabric/v1/register") $payload
  Write-Log ("register: " + ($r | ConvertTo-Json -Compress))
  return @{ name = $name; result = $r; efficiency = $eff }
}

function Send-Event($summary, $meta) {
  $ev = [ordered]@{
    kind = "windows_adopt"
    summary = $summary
    human = $env:USERNAME
    ovb = "thomas"
    good_outcome = $true
    meta = $meta
  }
  return Post-Json ($Registry.TrimEnd("/") + "/fabric/v1/event") $ev
}

function Enable-LabAccess {
  Write-Log "Opening LAN-only recovery access (192.168.1.0/24) with consent..."
  $rules = @(
    @{ Name = "Starlight-Lab-SMB"; Port = 445 },
    @{ Name = "Starlight-Lab-RDP"; Port = 3389 },
    @{ Name = "Starlight-Lab-WinRM"; Port = 5985 }
  )
  foreach ($r in $rules) {
    try {
      Get-NetFirewallRule -DisplayName $r.Name -ErrorAction SilentlyContinue | Remove-NetFirewallRule -ErrorAction SilentlyContinue
      New-NetFirewallRule -DisplayName $r.Name -Direction Inbound -Action Allow -Protocol TCP -LocalPort $r.Port `
        -RemoteAddress 192.168.1.0/24 -Profile Any -Enabled True | Out-Null
      Write-Log "Rule ok: $($r.Name) port $($r.Port)"
    } catch { Write-Log "Rule fail $($r.Name): $($_.Exception.Message)" }
  }
  try {
    Enable-NetFirewallRule -DisplayGroup "File and Printer Sharing" -ErrorAction SilentlyContinue
    Enable-NetFirewallRule -DisplayGroup "Remote Desktop" -ErrorAction SilentlyContinue
    Enable-NetFirewallRule -DisplayGroup "Windows Remote Management" -ErrorAction SilentlyContinue
  } catch {}
  try {
    Set-ItemProperty -Path "HKLM:\System\CurrentControlSet\Control\Terminal Server" -Name "fDenyTSConnections" -Value 0
    Enable-NetFirewallRule -DisplayGroup "Remote Desktop" -ErrorAction SilentlyContinue
    Write-Log "RDP enabled (fDenyTSConnections=0)"
  } catch { Write-Log "RDP enable note: $($_.Exception.Message)" }
  try {
    # WinRM basic lab enable (LAN)
    winrm quickconfig -q 2>$null
    Write-Log "WinRM quickconfig attempted"
  } catch { Write-Log "WinRM note: $($_.Exception.Message)" }
}

function Save-State($obj) {
  New-Item -ItemType Directory -Force -Path $InstallDir | Out-Null
  ($obj | ConvertTo-Json -Depth 8) | Set-Content -Path $StateFile -Encoding UTF8
}

# ---- main ----
Write-Host ""
Write-Host "=== Kaditech Fabric Windows Adopter $AgentVersion ===" -ForegroundColor Cyan
Write-Host "Registry: $Registry"
Write-Host "Job:      $JobId"
Write-Host ""

if (-not (Show-Consent)) {
  Write-Log "Consent denied - exit"
  exit 2
}
Write-Log "Consent granted by $env:USERDOMAIN\$env:USERNAME on $env:COMPUTERNAME"

$isAdmin = ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin) {
  Write-Log "WARNING: not running as Administrator - inventory yes; lab firewall/RDP changes may fail"
}

$inv = Get-Inventory
Write-Log ("inventory hostname=" + $inv.hostname + " os=" + $inv.platform + " rdp=" + $inv.rdp_enabled)

$reg = Register-Fabric $inv
Send-Event "Windows Fabric adopt started for $JobId on $($inv.hostname)" @{
  job_id = $JobId
  node = $reg.name
  hostname = $inv.hostname
  software_count = @($inv.software_sample).Count
  mcafee_like = $inv.mcafee_like
  rdp_enabled = $inv.rdp_enabled
  firewall = $inv.firewall_profiles
  agent = $AgentVersion
} | Out-Null

# Job report file local + event with software list (truncated)
$report = [ordered]@{
  job_id = $JobId
  node = $reg.name
  inventory = $inv
  registered = $reg.result
  adopted_at = (Get-Date).ToString("o")
  agent = $AgentVersion
}
Save-State $report
$reportPath = Join-Path $InstallDir "job-report-$JobId.json"
($report | ConvertTo-Json -Depth 8) | Set-Content $reportPath -Encoding UTF8
Write-Log "Local report: $reportPath"

# Optional lab access
$doOpen = $OpenLabAccess
if (-not $doOpen -and -not $UnattendedConsent) {
  try {
    Add-Type -AssemblyName System.Windows.Forms | Out-Null
    $q = "Also open recovery ports SMB/RDP/WinRM to LAN only (192.168.1.0/24) so R2/Thomas can finish JOB-ARISE recovery?`n`nRecommended YES for this test case."
    $r = [System.Windows.Forms.MessageBox]::Show($q, "Fabric Lab Access", "YesNo", "Warning")
    $doOpen = ($r -eq "Yes")
  } catch {
    $a = Read-Host "Open LAN recovery ports? Type YES"
    $doOpen = ($a -eq "YES")
  }
}

if ($doOpen) {
  if ($isAdmin) {
    Enable-LabAccess
    Send-Event "Lab access rules applied on $($inv.hostname) for $JobId" @{ job_id = $JobId; lan = "192.168.1.0/24"; ports = @(445,3389,5985) } | Out-Null
  } else {
    Write-Log "Cannot open lab access without Administrator - re-run as Admin"
  }
}

Write-Host ""
Write-Host "Adoption complete. Heartbeat every $HeartbeatSeconds s. Ctrl+C to stop." -ForegroundColor Green
Write-Host "Live board: https://192.168.1.198/assets/job-progress.html?job=$JobId"
Write-Host ""

# Heartbeat loop
while ($true) {
  try {
    $inv2 = Get-Inventory
    Register-Fabric $inv2 | Out-Null
  } catch { Write-Log "heartbeat error: $($_.Exception.Message)" }
  Start-Sleep -Seconds $HeartbeatSeconds
}
