Kaditech Fabric Adopt (Windows) - recovery / full field adoption
Run as Administrator. Consent required.
For normal employee field client, use Fabric-Client-Windows.zip instead.
