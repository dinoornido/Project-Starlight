#Requires -Version 5.1
$InstallDir = Join-Path $env:ProgramData "Kaditech\FabricAdopt"
$names = @("Starlight-Lab-SMB","Starlight-Lab-RDP","Starlight-Lab-WinRM")
foreach ($n in $names) {
  Get-NetFirewallRule -DisplayName $n -ErrorAction SilentlyContinue | Remove-NetFirewallRule -ErrorAction SilentlyContinue
}
Write-Host "Removed Starlight lab firewall rules (if present)."
Write-Host "Install dir left for logs: $InstallDir (delete manually if desired)"
Write-Host "Stop any running Fabric-Adopt.ps1 window (Ctrl+C) to end heartbeat."
