Kaditech Project Starlight - Fabric Client (Windows) v1.2
========================================================

1) Right-click Run-Client.cmd -> Run as administrator (recommended)
   or: powershell -ExecutionPolicy Bypass -File Fabric-Client.ps1

2) Approve the consent dialog.

3) Optional LAN: place wg-client.conf (admin-issued) next to this script
   or pass -WgConfig "C:\path\wg-client.conf"

4) Heartbeat registers with:
   LAN  http://192.168.1.198:3055
   VPN  http://10.8.0.1:3055

5) Uninstall: Uninstall-Fabric-Client.ps1

If PowerShell reports "string is missing the terminator", you have an old
broken zip (smart quotes). Re-download Fabric-Client-Windows.zip v1.2.

Ben / staff: after install, open Betty chat at Help -> Betty for support.
