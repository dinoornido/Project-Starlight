Kaditech Fabric Client v1.5 - Windows field client
=================================================
INSTALL: Run-Client.cmd  (consent, inventory, silent heartbeat)
POPUP FIX (if PowerShell flashes after older install):
  Run Fix-Silent-Heartbeat.cmd once
UNINSTALL: Uninstall-Fabric-Client.ps1
