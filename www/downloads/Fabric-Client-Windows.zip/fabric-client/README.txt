Kaditech Project Starlight - Fabric Client (Windows) v1.3
========================================================

HOW TO RUN (important)
----------------------
1) Unzip this folder completely (do not run from inside the zip).
2) Double-click:  Run-Client.cmd
   (If nothing seems to happen: right-click -> Run as administrator)
3) A black window MUST stay open and show green text.
4) Approve Yes on the popup (or type YES in the window).
5) Wait until you see:  SUCCESS. Fabric client is set up on this PC.

Do NOT only double-click Fabric-Client.ps1 (window can vanish).
Always use Run-Client.cmd

If download "flashes": check your Downloads folder for
  Fabric-Client-Windows.zip  (about 4 KB)

Uninstall: double-click is not enough - run:
  powershell -ExecutionPolicy Bypass -File Uninstall-Fabric-Client.ps1

Support: Betty staff desk / Ben desk links from email.
