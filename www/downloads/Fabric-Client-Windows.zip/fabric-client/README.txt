Kaditech Fabric Client Windows v1.4
===================================
1) Prefer WireGuard office tunnel (tech fabric) BEFORE Run-Client if remote:
   Install WireGuard, import your wg-client.conf from Betty, Activate tunnel.
2) Then double-click Run-Client.cmd
3) Should reach registry at 10.8.0.1 or 192.168.1.198 or https://96.68.140.57/fabric

SysAide (after WireGuard up): http://192.168.1.101:8080
