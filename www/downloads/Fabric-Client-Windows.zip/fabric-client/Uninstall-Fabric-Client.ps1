#Requires -Version 5.1
# Kaditech Fabric Client uninstall (ASCII-only)
$ErrorActionPreference = "Continue"
$InstallDir = Join-Path $env:ProgramData "Kaditech\FabricClient"
try {
  Unregister-ScheduledTask -TaskName "KaditechFabricHeartbeat" -Confirm:$false -ErrorAction SilentlyContinue
} catch {}
if (Test-Path -LiteralPath $InstallDir) {
  Remove-Item -LiteralPath $InstallDir -Recurse -Force -ErrorAction SilentlyContinue
}
Write-Host "Fabric Client removed (task + ProgramData state)."
