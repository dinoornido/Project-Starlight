$ErrorActionPreference = "Continue"
Write-Host "Removing Kaditech Fabric Client..."
$InstallDir = Join-Path $env:ProgramData "Kaditech\FabricClient"
try { Unregister-ScheduledTask -TaskName "KaditechFabricHeartbeat" -Confirm:$false -ErrorAction SilentlyContinue } catch {}
if (Test-Path -LiteralPath $InstallDir) {
  Remove-Item -LiteralPath $InstallDir -Recurse -Force -ErrorAction SilentlyContinue
}
Write-Host "Done. Press Enter."
try { [void](Read-Host) } catch {}
