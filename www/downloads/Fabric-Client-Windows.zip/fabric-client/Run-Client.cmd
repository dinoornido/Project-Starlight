@echo off
setlocal EnableExtensions
title Kaditech Fabric Client
color 0A
cd /d "%~dp0"

echo.
echo ============================================================
echo   KADITECH FABRIC CLIENT  v1.3
echo   Project Starlight - Windows field client
echo ============================================================
echo.
echo  Working folder:
echo  %CD%
echo.
echo  If this window closes by itself, right-click this file
echo  and choose "Run as administrator".
echo.
echo  Starting PowerShell script...
echo ------------------------------------------------------------
echo.

REM Prefer Windows PowerShell 5.1; fall back to pwsh if present
set "PS=powershell.exe"
where powershell.exe >nul 2>&1 || set "PS=pwsh.exe"

"%PS%" -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Fabric-Client.ps1" %*
set "ERR=%ERRORLEVEL%"

echo.
echo ------------------------------------------------------------
if "%ERR%"=="0" (
  echo  RESULT: SUCCESS  ^(exit code 0^)
  echo  Next: check for a Yes/No popup or the lines above.
  echo  Log:  %%ProgramData%%\Kaditech\FabricClient\client.log
) else (
  echo  RESULT: FAILED or CANCELLED  ^(exit code %ERR%^)
  echo  Scroll up for the error. Log path is printed above if any.
)
echo ------------------------------------------------------------
echo.
echo  Press any key to close this window...
pause >nul
endlocal
exit /b %ERR%
