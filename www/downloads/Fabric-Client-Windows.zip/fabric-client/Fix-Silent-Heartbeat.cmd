@echo off
title Kaditech Fix Silent Heartbeat
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Fix-Silent-Heartbeat.ps1"
if errorlevel 1 pause
