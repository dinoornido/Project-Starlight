# Kaditech Fabric Client v1.4 - ASCII only - console always talks
param(
  [string]$Registry = "",
  [string]$NodeName = "",
  [string]$WgConfig = "",
  [switch]$UnattendedConsent
)

$Host.UI.RawUI.WindowTitle = "Kaditech Fabric Client v1.4"
$ErrorActionPreference = "Continue"
$AgentVersion = "fabric-windows-client/1.4.0"
$InstallDir = Join-Path $env:ProgramData "Kaditech\FabricClient"
$LogFile = Join-Path $InstallDir "client.log"
$StateFile = Join-Path $InstallDir "state.json"
$RegistryLan = "http://192.168.1.198:3055"
$RegistryVpn = "http://10.8.0.1:3055"
$RegistryWan1 = "https://kaditech.com"
$RegistryWan2 = "https://www.kaditech.com"

function Write-Log {
  param([string]$Msg)
  $line = "[{0}] {1}" -f (Get-Date -Format "yyyy-MM-dd HH:mm:ss"), $Msg
  try {
    if (-not (Test-Path -LiteralPath $InstallDir)) {
      New-Item -ItemType Directory -Force -Path $InstallDir | Out-Null
    }
    Add-Content -Path $LogFile -Value $line -Encoding UTF8
  } catch {}
  Write-Host $line
}

function Write-Banner {
  param([string]$Text, [string]$Color = "Cyan")
  Write-Host ""
  Write-Host ("==== {0} ====" -f $Text) -ForegroundColor $Color
}

# --- IMMEDIATE feedback (before anything that can hang) ---
Write-Host ""
Write-Host "Kaditech Fabric Client v1.4 starting..." -ForegroundColor Green
Write-Host ("User: {0}  PC: {1}" -f $env:USERNAME, $env:COMPUTERNAME)
Write-Host ("PowerShell: {0}" -f $PSVersionTable.PSVersion)
Write-Host ("Script: {0}" -f $MyInvocation.MyCommand.Path)
Write-Host ""

try {
  Write-Banner "STEP 1/6  Consent"
  $title = "Kaditech Fabric Client"
  $body = "Project Starlight Fabric Client (OPT-IN)`r`n`r`nThis will:`r`n1) Inventory this PC (name, OS, disk, user)`r`n2) Register a Fabric heartbeat with Kaditech`r`n3) Optionally import WireGuard if you have wg-client.conf`r`n`r`nNot silent. Uninstall with Uninstall-Fabric-Client.ps1`r`n`r`nApprove on this computer?"

  $approved = $false
  if ($UnattendedConsent) {
    $approved = $true
    Write-Log "UnattendedConsent = yes"
  } else {
    Write-Host "Showing consent prompt..."
    try {
      Add-Type -AssemblyName System.Windows.Forms -ErrorAction Stop
      $r = [System.Windows.Forms.MessageBox]::Show(
        $body, $title,
        [System.Windows.Forms.MessageBoxButtons]::YesNo,
        [System.Windows.Forms.MessageBoxIcon]::Question
      )
      $approved = ($r -eq [System.Windows.Forms.DialogResult]::Yes)
      Write-Log ("MessageBox result = " + $r)
    } catch {
      Write-Host "Popup not available - using console consent." -ForegroundColor Yellow
      Write-Host $body
      Write-Host ""
      $a = Read-Host "Type YES and press Enter to approve (anything else cancels)"
      $approved = ($a -eq "YES" -or $a -eq "yes" -or $a -eq "Y" -or $a -eq "y")
      Write-Log ("Console consent = " + $approved)
    }
  }

  if (-not $approved) {
    Write-Host ""
    Write-Host "CANCELLED - you did not approve. Nothing was installed." -ForegroundColor Yellow
    Write-Host "Close this window, or press Enter."
    try { [void](Read-Host) } catch {}
    exit 2
  }

  Write-Banner "STEP 2/6  Folders"
  New-Item -ItemType Directory -Force -Path $InstallDir | Out-Null
  Write-Log ("Install dir: " + $InstallDir)

  Write-Banner "STEP 3/6  Inventory"
  $cs = $null; $os = $null; $disk = @()
  try { $cs = Get-CimInstance Win32_ComputerSystem } catch { Write-Log ("WMI CS: " + $_.Exception.Message) }
  try { $os = Get-CimInstance Win32_OperatingSystem } catch { Write-Log ("WMI OS: " + $_.Exception.Message) }
  try {
    $disk = @(Get-CimInstance Win32_LogicalDisk -Filter "DriveType=3" | ForEach-Object {
      [pscustomobject]@{
        device  = $_.DeviceID
        free_gb = [math]::Round(($_.FreeSpace / 1GB), 2)
        size_gb = [math]::Round(($_.Size / 1GB), 2)
      }
    })
  } catch { Write-Log ("WMI Disk: " + $_.Exception.Message) }

  $inv = @{
    hostname     = $env:COMPUTERNAME
    user         = $env:USERNAME
    domain       = $env:USERDOMAIN
    platform     = if ($os) { $os.Caption } else { "Windows" }
    version      = if ($os) { $os.Version } else { "" }
    manufacturer = if ($cs) { $cs.Manufacturer } else { "" }
    model        = if ($cs) { $cs.Model } else { "" }
    mem_gb       = if ($cs) { [math]::Round($cs.TotalPhysicalMemory / 1GB, 2) } else { 0 }
    disks        = $disk
  }
  Write-Log ("Inventory: " + ($inv | ConvertTo-Json -Compress))

  if (-not $NodeName) {
    $NodeName = ("win-" + $env:COMPUTERNAME + "-" + $env:USERNAME).ToLower() -replace "[^a-z0-9\-]", "-"
  }
  Write-Log ("Node name: " + $NodeName)

  Write-Banner "STEP 4/6  Find Fabric registry"
  $reg = $Registry
  # Prefer office mesh first, then public HTTPS Fabric on TA edge
  $candidates = @(
    "http://10.8.0.1:3055",
    "http://192.168.1.198:3055",
    "https://96.68.140.57",
    "http://192.168.1.198:3055"
  )
  if ($Registry) { $candidates = @($Registry) + $candidates }
  if (-not $reg) {
    foreach ($u in $candidates) {
      try {
        $health = $u.TrimEnd("/") + "/fabric/v1/health"
        Write-Host ("  Trying " + $health + " ...")
        if ($health -like "https://*") {
          try { [System.Net.ServicePointManager]::ServerCertificateValidationCallback = { $true } } catch {}
          $resp = Invoke-WebRequest -Uri $health -UseBasicParsing -TimeoutSec 6
        } else {
          $resp = Invoke-WebRequest -Uri $health -UseBasicParsing -TimeoutSec 4
        }
        if ($resp.StatusCode -eq 200) {
          $reg = $u
          Write-Log ("Registry reachable: " + $u)
          break
        }
      } catch {
        Write-Host ("  not reachable: " + $u) -ForegroundColor DarkYellow
      }
    }
  }
  if (-not $reg) {
    $reg = $RegistryVpn
    Write-Log ("No registry ping ok yet - will use " + $reg + " (VPN when online)")
  }

  Write-Banner "STEP 5/6  Register + heartbeat task"
  $payload = @{
    name       = $NodeName
    role       = "field_client"
    agent      = $AgentVersion
    layer      = "experience_time"
    efficiency = 0.75
    inventory  = $inv
  } | ConvertTo-Json -Depth 6

  $url = $reg.TrimEnd("/") + "/fabric/v1/register"
  Write-Log ("POST " + $url)
  $registered = $false
  try {
    $resp = Invoke-RestMethod -Uri $url -Method Post -Body $payload -ContentType "application/json; charset=utf-8" -TimeoutSec 20
    Write-Log ("Register OK: " + ($resp | ConvertTo-Json -Compress))
    $registered = $true
  } catch {
    Write-Log ("Register deferred (offline ok): " + $_.Exception.Message)
    Write-Host "  Note: lab/VPN not reachable from this network right now." -ForegroundColor Yellow
    Write-Host "  Client is still installed; heartbeat will retry later." -ForegroundColor Yellow
  }

  @{
    name      = $NodeName
    registry  = $reg
    agent     = $AgentVersion
    installed = (Get-Date).ToString("o")
    registered_now = $registered
  } | ConvertTo-Json | Set-Content -Path $StateFile -Encoding ASCII
  Write-Log ("State written: " + $StateFile)

  # Heartbeat script
  $ps1 = Join-Path $InstallDir "heartbeat.ps1"
  $hb = @(
    '$ErrorActionPreference = "SilentlyContinue"'
    ('$reg = "{0}"' -f $reg.Replace('"',''))
    ('$name = "{0}"' -f $NodeName.Replace('"',''))
    '$os = try { (Get-CimInstance Win32_OperatingSystem).Caption } catch { "Windows" }'
    '$inv = @{ hostname = $env:COMPUTERNAME; user = $env:USERNAME; platform = $os }'
    ('$body = @{{ name = $name; role = "field_client"; agent = "{0}"; inventory = $inv; efficiency = 0.75 }} | ConvertTo-Json -Depth 4' -f $AgentVersion)
    'try {'
    '  $uri = $reg.TrimEnd("/") + "/fabric/v1/register"'
    '  Invoke-RestMethod -Uri $uri -Method Post -Body $body -ContentType "application/json" -TimeoutSec 15 | Out-Null'
    '} catch {}'
  )
  Set-Content -Path $ps1 -Value $hb -Encoding ASCII
  Write-Log ("Heartbeat script: " + $ps1)

  try {
    $arg = '-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "' + $ps1 + '"'
    $action = New-ScheduledTaskAction -Execute "powershell.exe" -Argument $arg
    $trigger = New-ScheduledTaskTrigger -Once -At (Get-Date).AddMinutes(1) -RepetitionInterval (New-TimeSpan -Minutes 5) -RepetitionDuration (New-TimeSpan -Days 3650)
    Register-ScheduledTask -TaskName "KaditechFabricHeartbeat" -Action $action -Trigger $trigger -Force -ErrorAction Stop | Out-Null
    Write-Log "Scheduled task KaditechFabricHeartbeat installed"
  } catch {
    Write-Log ("Scheduled task note (non-fatal): " + $_.Exception.Message)
    Write-Host "  Heartbeat task not installed (need admin for task). Manual OK." -ForegroundColor Yellow
  }

  Write-Banner "STEP 6/6  WireGuard (optional)"
  $conf = $WgConfig
  if (-not $conf) {
    $beside = Join-Path $PSScriptRoot "wg-client.conf"
    if (Test-Path -LiteralPath $beside) { $conf = $beside }
  }
  if ($conf -and (Test-Path -LiteralPath $conf)) {
    $dest = Join-Path $InstallDir "wg-client.conf"
    Copy-Item -LiteralPath $conf -Destination $dest -Force
    Write-Log ("WireGuard profile saved: " + $dest)
    Write-Host "Import that file in WireGuard for Windows when ready."
  } else {
    Write-Log "No wg-client.conf - VPN skipped (admin can send later)"
    Write-Host "  No VPN profile in this folder - that is normal for first install."
  }

  Write-Banner "DONE - INSTALL COMPLETE" "Green"
  Write-Host ""
  Write-Host "  SUCCESS. Fabric client is set up on this PC." -ForegroundColor Green
  Write-Host ("  Node:     " + $NodeName)
  Write-Host ("  Registry: " + $reg)
  Write-Host ("  Log:      " + $LogFile)
  Write-Host ("  State:    " + $StateFile)
  if ($registered) {
    Write-Host "  Registry: reached and registered this session." -ForegroundColor Green
  } else {
    Write-Host "  Registry: not reached this session (offline/VPN) - will retry." -ForegroundColor Yellow
  }
  Write-Host ""
  Write-Host "  You can close this window after reading the log path."
  Write-Host "  Press Enter to exit..."
  try { [void](Read-Host) } catch {}
  exit 0

} catch {
  Write-Host ""
  Write-Host "FATAL ERROR" -ForegroundColor Red
  Write-Host $_.Exception.Message -ForegroundColor Red
  Write-Host $_.ScriptStackTrace
  try { Write-Log ("FATAL: " + $_.Exception.Message) } catch {}
  Write-Host ""
  Write-Host "Press Enter to exit..."
  try { [void](Read-Host) } catch {}
  exit 1
}
