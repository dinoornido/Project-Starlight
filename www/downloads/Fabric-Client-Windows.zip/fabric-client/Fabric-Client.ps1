#Requires -Version 5.1
<#
.SYNOPSIS
  Kaditech Project Starlight - Fabric Client (Windows) v1.2
.DESCRIPTION
  Employee / on-site field client. Consent-based.
  - Inventory + Fabric registry heartbeat
  - Optional WireGuard (WireGuard for Windows) if conf provided
  ASCII-only source (avoids PowerShell string-terminator failures on smart quotes).
#>
param(
  [string]$Registry = "",
  [string]$NodeName = "",
  [string]$WgConfig = "",
  [switch]$UnattendedConsent
)

$ErrorActionPreference = "Continue"
$AgentVersion = "fabric-windows-client/1.2.1"
$InstallDir = Join-Path $env:ProgramData "Kaditech\FabricClient"
$LogFile = Join-Path $InstallDir "client.log"
$StateFile = Join-Path $InstallDir "state.json"
$RegistryLan = "http://192.168.1.198:3055"
$RegistryVpn = "http://10.8.0.1:3055"

function Write-Log {
  param([string]$Msg)
  $line = "[{0}] {1}" -f (Get-Date -Format o), $Msg
  try {
    New-Item -ItemType Directory -Force -Path $InstallDir | Out-Null
    Add-Content -Path $LogFile -Value $line -Encoding UTF8
  } catch {}
  Write-Host $line
}

function Show-Consent {
  $title = "Kaditech Fabric Client"
  $body = @(
    "Project Starlight - Fabric Client (OPT-IN)",
    "",
    "This will:",
    "1) Inventory this PC (name, OS, disk, user)",
    "2) Register a Fabric heartbeat with Kaditech (lab or VPN)",
    "3) Optionally import a WireGuard profile for LAN access (if you provide one)",
    "",
    "Not silent. Not spyware. Uninstall: Uninstall-Fabric-Client.ps1",
    "",
    "Approve installation on this computer?"
  ) -join [Environment]::NewLine

  if ($UnattendedConsent) { return $true }
  try {
    Add-Type -AssemblyName System.Windows.Forms | Out-Null
    $r = [System.Windows.Forms.MessageBox]::Show($body, $title, "YesNo", "Question")
    return ($r -eq "Yes")
  } catch {
    Write-Host $body
    $a = Read-Host "Type YES to approve"
    return ($a -eq "YES")
  }
}

function Get-Inventory {
  $cs = Get-CimInstance Win32_ComputerSystem
  $os = Get-CimInstance Win32_OperatingSystem
  $disk = Get-CimInstance Win32_LogicalDisk -Filter "DriveType=3" | ForEach-Object {
    [pscustomobject]@{
      device  = $_.DeviceID
      free_gb = [math]::Round(($_.FreeSpace / 1GB), 2)
      size_gb = [math]::Round(($_.Size / 1GB), 2)
    }
  }
  $rdpDeny = $null
  try {
    $rdpDeny = (Get-ItemProperty -Path "HKLM:\System\CurrentControlSet\Control\Terminal Server" -Name fDenyTSConnections -ErrorAction SilentlyContinue).fDenyTSConnections
  } catch {}
  return @{
    hostname     = $env:COMPUTERNAME
    user         = $env:USERNAME
    domain       = $env:USERDOMAIN
    platform     = $os.Caption
    version      = $os.Version
    manufacturer = $cs.Manufacturer
    model        = $cs.Model
    mem_gb       = [math]::Round($cs.TotalPhysicalMemory / 1GB, 2)
    disks        = @($disk)
    rdp_enabled  = ($rdpDeny -eq 0)
  }
}

function Pick-Registry {
  if ($Registry) { return $Registry }
  foreach ($u in @($RegistryLan, $RegistryVpn)) {
    try {
      $health = $u.TrimEnd("/") + "/fabric/v1/health"
      $r = Invoke-WebRequest -Uri $health -UseBasicParsing -TimeoutSec 3
      if ($r.StatusCode -eq 200) { return $u }
    } catch {}
  }
  return $RegistryVpn
}

function Register-Node {
  param($Reg, $Name, $Inv)
  $payload = @{
    name       = $Name
    role       = "field_client"
    agent      = $AgentVersion
    layer      = "experience_time"
    efficiency = 0.75
    inventory  = $Inv
  } | ConvertTo-Json -Depth 6
  $url = $Reg.TrimEnd("/") + "/fabric/v1/register"
  Write-Log ("POST " + $url + " as " + $Name)
  try {
    $resp = Invoke-RestMethod -Uri $url -Method Post -Body $payload -ContentType "application/json; charset=utf-8" -TimeoutSec 20
    Write-Log ("register ok: " + ($resp | ConvertTo-Json -Compress))
    return $true
  } catch {
    Write-Log ("register failed: " + $_.Exception.Message)
    return $false
  }
}

function Install-HeartbeatTask {
  param($Reg, $Name)
  $ps1 = Join-Path $InstallDir "heartbeat.ps1"
  $lines = @(
    '$ErrorActionPreference = "SilentlyContinue"',
    ('$reg = "{0}"' -f $Reg.Replace('"', '')),
    ('$name = "{0}"' -f $Name.Replace('"', '')),
    '$os = (Get-CimInstance Win32_OperatingSystem).Caption',
    '$inv = @{ hostname = $env:COMPUTERNAME; user = $env:USERNAME; platform = $os }',
    ('$body = @{{ name = $name; role = "field_client"; agent = "{0}"; inventory = $inv; efficiency = 0.75 }} | ConvertTo-Json -Depth 4' -f $AgentVersion),
    'try {',
    '  $uri = $reg.TrimEnd("/") + "/fabric/v1/register"',
    '  Invoke-RestMethod -Uri $uri -Method Post -Body $body -ContentType "application/json" -TimeoutSec 15 | Out-Null',
    '} catch {}'
  )
  Set-Content -Path $ps1 -Value $lines -Encoding ASCII

  $arg = '-NoProfile -ExecutionPolicy Bypass -File "' + $ps1 + '"'
  $action = New-ScheduledTaskAction -Execute "powershell.exe" -Argument $arg
  $trigger = New-ScheduledTaskTrigger -Once -At (Get-Date).AddMinutes(1) -RepetitionInterval (New-TimeSpan -Minutes 1) -RepetitionDuration ([TimeSpan]::MaxValue)
  try {
    Register-ScheduledTask -TaskName "KaditechFabricHeartbeat" -Action $action -Trigger $trigger -Force -User $env:USERNAME | Out-Null
    Write-Log "Scheduled task KaditechFabricHeartbeat installed"
  } catch {
    Write-Log ("task install note: " + $_.Exception.Message)
  }
}

function Import-WireGuardIfPresent {
  $conf = $WgConfig
  if (-not $conf) {
    $beside = Join-Path $PSScriptRoot "wg-client.conf"
    if (Test-Path -LiteralPath $beside) { $conf = $beside }
  }
  if (-not $conf) {
    Write-Log "No wg-client.conf provided - VPN skip. Admin issues personal profile for LAN."
    return
  }
  if (-not (Test-Path -LiteralPath $conf)) {
    Write-Log ("WireGuard conf not found: " + $conf)
    return
  }
  $dest = Join-Path $InstallDir "wg-client.conf"
  Copy-Item -LiteralPath $conf -Destination $dest -Force
  Write-Log ("WireGuard profile saved to " + $dest)
  Write-Host ""
  Write-Host "Install WireGuard for Windows from https://www.wireguard.com/install/"
  Write-Host "Then: WireGuard app -> Import tunnel(s) from file -> select:"
  Write-Host ("  " + $dest)
  Write-Host "Activate tunnel. Test: ping 10.8.0.1"
}

# --- main ---
if (-not (Show-Consent)) {
  Write-Host "Cancelled."
  exit 1
}
New-Item -ItemType Directory -Force -Path $InstallDir | Out-Null
$inv = Get-Inventory
if (-not $NodeName) {
  $NodeName = ("win-" + $env:COMPUTERNAME + "-" + $env:USERNAME).ToLower()
}
$reg = Pick-Registry
Write-Log ("Registry=" + $reg + " Node=" + $NodeName)
[void](Register-Node -Reg $reg -Name $NodeName -Inv $inv)
@{
  name     = $NodeName
  registry = $reg
  agent    = $AgentVersion
  installed = (Get-Date).ToString("o")
} | ConvertTo-Json | Set-Content -Path $StateFile -Encoding ASCII
Install-HeartbeatTask -Reg $reg -Name $NodeName
Import-WireGuardIfPresent
Write-Log ("Fabric Windows client installed (" + $AgentVersion + ")")
Write-Host ""
Write-Host "Done. Fabric heartbeat active when reachable."
Write-Host "For LAN: import admin-issued WireGuard profile (wg-client.conf)."
Write-Host "Log: $LogFile"
