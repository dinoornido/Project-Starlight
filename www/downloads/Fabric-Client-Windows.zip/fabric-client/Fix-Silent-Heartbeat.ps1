# Kaditech - stop PowerShell popup flash from Fabric heartbeat
# Run once: right-click > Run with PowerShell  (or: powershell -ExecutionPolicy Bypass -File Fix-Silent-Heartbeat.ps1)
$ErrorActionPreference = "Continue"
$InstallDir = Join-Path $env:ProgramData "Kaditech\FabricClient"
$ps1 = Join-Path $InstallDir "heartbeat.ps1"
$vbs = Join-Path $InstallDir "heartbeat-run.vbs"
$LogFile = Join-Path $InstallDir "client.log"

function L($m) {
  $line = "[{0}] FIX-SILENT: {1}" -f (Get-Date -Format "yyyy-MM-dd HH:mm:ss"), $m
  try { if (Test-Path $InstallDir) { Add-Content $LogFile $line -Encoding UTF8 } } catch {}
  Write-Host $line
}

Write-Host ""
Write-Host "Kaditech Fabric - Fix silent heartbeat (no PowerShell popups)" -ForegroundColor Cyan
Write-Host ""

if (-not (Test-Path $InstallDir)) {
  Write-Host "Fabric not installed at $InstallDir" -ForegroundColor Red
  Write-Host "Install Fabric Client v1.5 first, then re-run this fix if needed."
  Read-Host "Enter to exit"; exit 1
}

if (-not (Test-Path $ps1)) {
  # minimal heartbeat if missing
  $reg = "http://10.8.0.1:3055"
  try {
    $st = Get-Content (Join-Path $InstallDir "state.json") -Raw | ConvertFrom-Json
    if ($st.registry) { $reg = [string]$st.registry }
  } catch {}
  $name = "win-" + ($env:COMPUTERNAME.ToLower())
  try { if ($st.name) { $name = [string]$st.name } } catch {}
  @"
`$ErrorActionPreference = "SilentlyContinue"
`$reg = "$reg"
`$name = "$name"
`$os = try { (Get-CimInstance Win32_OperatingSystem).Caption } catch { "Windows" }
`$inv = @{ hostname = `$env:COMPUTERNAME; user = `$env:USERNAME; platform = `$os }
`$body = @{ name = `$name; role = "field_client"; agent = "fabric-windows-client/1.5.0"; inventory = `$inv; efficiency = 0.75 } | ConvertTo-Json -Depth 4
try {
  `$uri = `$reg.TrimEnd("/") + "/fabric/v1/register"
  Invoke-RestMethod -Uri `$uri -Method Post -Body `$body -ContentType "application/json" -TimeoutSec 15 | Out-Null
} catch {}
"@ | Set-Content $ps1 -Encoding ASCII
  L "Wrote heartbeat.ps1"
}

$ps1Esc = $ps1 -replace '"','""'
@"
' Kaditech Fabric silent heartbeat - do not delete
Dim sh, cmd
Set sh = CreateObject("WScript.Shell")
cmd = "powershell.exe -NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -WindowStyle Hidden -File ""$ps1Esc"""
sh.Run cmd, 0, False
"@ | Set-Content $vbs -Encoding ASCII
L "Wrote $vbs"

try { Unregister-ScheduledTask -TaskName "KaditechFabricHeartbeat" -Confirm:$false -ErrorAction SilentlyContinue } catch {}
try {
  $action = New-ScheduledTaskAction -Execute "wscript.exe" -Argument ('//B //Nologo "' + $vbs + '"')
  $trigger = New-ScheduledTaskTrigger -Once -At (Get-Date).AddMinutes(1) -RepetitionInterval (New-TimeSpan -Minutes 5) -RepetitionDuration (New-TimeSpan -Days 3650)
  $settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable -ExecutionTimeLimit (New-TimeSpan -Minutes 2) -MultipleInstances IgnoreNew
  try { $settings.Hidden = $true } catch {}
  $principal = New-ScheduledTaskPrincipal -UserId $env:USERNAME -LogonType Interactive -RunLevel Limited
  Register-ScheduledTask -TaskName "KaditechFabricHeartbeat" -Action $action -Trigger $trigger -Settings $settings -Principal $principal -Force | Out-Null
  L "Task KaditechFabricHeartbeat reinstalled SILENT"
  Write-Host ""
  Write-Host "SUCCESS. PowerShell should no longer flash." -ForegroundColor Green
  Write-Host "Heartbeat still runs every 5 minutes, fully hidden."
  Write-Host "Optional: Task Scheduler > KaditechFabricHeartbeat to confirm."
} catch {
  L ("FAILED: " + $_.Exception.Message)
  Write-Host "Could not rewrite task. Run PowerShell as Administrator and retry." -ForegroundColor Red
  Write-Host "Or disable task: Unregister-ScheduledTask -TaskName KaditechFabricHeartbeat -Confirm:`$false"
}

Write-Host ""
Read-Host "Enter to exit"
