#!/usr/bin/env bash
set -euo pipefail
INSTALL_DIR="${FABRIC_HOME:-$HOME/.local/share/kaditech/fabric}"
systemctl --user disable --now kaditech-fabric-heartbeat.timer 2>/dev/null || true
rm -f "$HOME/.config/systemd/user/kaditech-fabric-heartbeat."{service,timer}
systemctl --user daemon-reload 2>/dev/null || true
sudo wg-quick down kaditech-fabric 2>/dev/null || true
sudo rm -f /etc/wireguard/kaditech-fabric.conf
rm -rf "$INSTALL_DIR"
echo "Fabric Linux client removed."
