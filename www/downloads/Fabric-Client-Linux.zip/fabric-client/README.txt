Kaditech · Project Starlight — Fabric Client (Linux) v1.1
=========================================================

Purpose
  Employee / on-site field node: join Fabric heartbeat + optional WireGuard
  tunnel into Kaditech LAN (StarGate, Help, registry).

Quick start (Linux)
  1) unzip Fabric-Client-Linux.zip
  2) cd fabric-client
  3) chmod +x install.sh uninstall.sh
  4) ./install.sh
  5) Type YES when asked (consent)

LAN / VPN access
  Admin issues a personal WireGuard profile (wg-client.conf).
  Place it next to install.sh, then:
    ./install.sh ./wg-client.conf
  Or after install:
    sudo cp wg-client.conf /etc/wireguard/kaditech-fabric.conf
    sudo wg-quick up kaditech-fabric

Test
  ping 10.8.0.1
  curl http://10.8.0.1:3055/fabric/v1/health
  # if on lab Wi‑Fi without VPN:
  curl http://192.168.1.198:3055/fabric/v1/health

Uninstall
  ./uninstall.sh

Security
  - Consent required (type YES)
  - No silent install
  - WireGuard private keys are NEVER in the public zip — only admin-issued profiles
