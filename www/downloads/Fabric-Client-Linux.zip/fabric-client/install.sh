#!/usr/bin/env bash
# Kaditech Project Starlight — Fabric Client (Linux)
# Consent-based. Opt-in only. For employees / on-site tech.
set -euo pipefail
VERSION="fabric-linux-client/1.1"
INSTALL_DIR="${FABRIC_HOME:-$HOME/.local/share/kaditech/fabric}"
STATE="$INSTALL_DIR/state.json"
LOG="$INSTALL_DIR/fabric-client.log"
REGISTRY_DEFAULT="http://10.8.0.1:3055"
# When on lab LAN without VPN:
REGISTRY_LAN="http://192.168.1.198:3055"

mkdir -p "$INSTALL_DIR"
log() { echo "[$(date -Iseconds)] $*" | tee -a "$LOG"; }

consent() {
  cat <<'TXT'

============================================================
  Kaditech · Project Starlight — Fabric Client (Linux)
============================================================
This is OPT-IN. Not spyware. Not silent.

With your approval this will:
  1) Inventory this machine (name, OS, CPU, RAM, disk)
  2) Register a Fabric heartbeat with Kaditech (lab/VPN)
  3) Optionally install WireGuard profile you were given
     so you can reach the Kaditech LAN (Help / StarGate)

You can uninstall with:  ./uninstall.sh

TXT
  read -r -p "Type YES to approve: " a
  [[ "$a" == "YES" ]] || { echo "Cancelled."; exit 1; }
}

inventory() {
  python3 - <<'PY'
import json, os, platform, socket, shutil
inv = {
  "hostname": socket.gethostname(),
  "platform": platform.platform(),
  "system": platform.system(),
  "release": platform.release(),
  "machine": platform.machine(),
  "python": platform.python_version(),
  "user": os.environ.get("USER") or os.environ.get("LOGNAME") or "",
  "cpus": os.cpu_count(),
}
try:
  with open("/proc/meminfo") as f:
    for line in f:
      if line.startswith("MemTotal:"):
        inv["mem_kb"] = int(line.split()[1]); break
except Exception:
  pass
try:
  usage = shutil.disk_usage("/")
  inv["disk_root_free_gb"] = round(usage.free/1e9, 2)
  inv["disk_root_total_gb"] = round(usage.total/1e9, 2)
except Exception:
  pass
print(json.dumps(inv))
PY
}

pick_registry() {
  if curl -sf -m 2 "$REGISTRY_LAN/health" >/dev/null 2>&1 || curl -sf -m 2 "$REGISTRY_LAN/fabric/v1/health" >/dev/null 2>&1; then
    echo "$REGISTRY_LAN"
  elif curl -sf -m 2 "$REGISTRY_DEFAULT/health" >/dev/null 2>&1 || curl -sf -m 2 "$REGISTRY_DEFAULT/fabric/v1/health" >/dev/null 2>&1; then
    echo "$REGISTRY_DEFAULT"
  else
    echo "${FABRIC_REGISTRY:-$REGISTRY_DEFAULT}"
  fi
}

register_once() {
  local reg name inv_json
  reg=$(pick_registry)
  name="${FABRIC_NODE_NAME:-linux-$(hostname -s)-$(id -u)}"
  inv_json=$(inventory)
  log "Registering $name → $reg"
  curl -sS -m 15 -X POST "$reg/fabric/v1/register" \
    -H "Content-Type: application/json" \
    -d "$(python3 - <<PY
import json
inv=json.loads('''$inv_json''')
print(json.dumps({
  "name": "$name",
  "role": "field_client",
  "agent": "$VERSION",
  "layer": "experience_time",
  "efficiency": 0.75,
  "inventory": inv,
}))
PY
)" | tee -a "$LOG"
  echo
  python3 - <<PY
import json, time
from pathlib import Path
state={
  "name": "$name",
  "registry": "$reg",
  "agent": "$VERSION",
  "installed": time.time(),
  "employee": True,
}
Path("$STATE").write_text(json.dumps(state, indent=2))
print("state written", "$STATE")
PY
}

install_wg_if_present() {
  local conf="${1:-}"
  if [[ -z "$conf" ]]; then
    conf="$(dirname "$0")/wg-client.conf"
  fi
  if [[ ! -f "$conf" ]]; then
    log "No WireGuard profile next to installer (expected wg-client.conf). Skip VPN — admin will issue profile for LAN access."
    return 0
  fi
  if ! command -v wg >/dev/null 2>&1; then
    log "Installing wireguard-tools (needs sudo)..."
    if command -v apt-get >/dev/null; then
      sudo apt-get update -qq && sudo apt-get install -y wireguard wireguard-tools openresolv || true
    elif command -v dnf >/dev/null; then
      sudo dnf install -y wireguard-tools || true
    fi
  fi
  if ! command -v wg >/dev/null 2>&1; then
    log "WireGuard not installed. Place profile and install wireguard-tools, then: sudo wg-quick up ./wg-client.conf"
    return 0
  fi
  sudo cp "$conf" /etc/wireguard/kaditech-fabric.conf
  sudo chmod 600 /etc/wireguard/kaditech-fabric.conf
  sudo wg-quick down kaditech-fabric 2>/dev/null || true
  sudo wg-quick up kaditech-fabric
  log "WireGuard up: kaditech-fabric (LAN via Fabric tunnel)"
  echo "Test: ping -c 2 10.8.0.1 && curl -sf http://10.8.0.1:3055/fabric/v1/health"
}

install_heartbeat() {
  cat > "$INSTALL_DIR/heartbeat.sh" <<'HB'
#!/usr/bin/env bash
set -euo pipefail
STATE="${FABRIC_HOME:-$HOME/.local/share/kaditech/fabric}/state.json"
LOG="${FABRIC_HOME:-$HOME/.local/share/kaditech/fabric}/fabric-client.log"
[[ -f "$STATE" ]] || exit 0
REG=$(python3 -c "import json; print(json.load(open('$STATE')).get('registry',''))")
NAME=$(python3 -c "import json; print(json.load(open('$STATE')).get('name',''))")
[[ -n "$REG" && -n "$NAME" ]] || exit 0
INV=$(python3 - <<'PY'
import json, os, platform, socket, shutil
inv={"hostname":socket.gethostname(),"platform":platform.platform(),"user":os.environ.get("USER",""),"cpus":os.cpu_count()}
try:
  u=shutil.disk_usage("/")
  inv["disk_root_free_gb"]=round(u.free/1e9,2)
except Exception: pass
print(json.dumps(inv))
PY
)
curl -sS -m 12 -X POST "$REG/fabric/v1/register" -H "Content-Type: application/json" \
  -d "{\"name\":\"$NAME\",\"role\":\"field_client\",\"agent\":\"fabric-linux-client/1.1\",\"inventory\":$INV,\"efficiency\":0.75}" \
  >>"$LOG" 2>&1 || true
echo >>"$LOG"
HB
  chmod +x "$INSTALL_DIR/heartbeat.sh"
  # user systemd if available
  mkdir -p "$HOME/.config/systemd/user"
  cat > "$HOME/.config/systemd/user/kaditech-fabric-heartbeat.service" <<SVC
[Unit]
Description=Kaditech Fabric field heartbeat
After=network-online.target

[Service]
Type=oneshot
ExecStart=$INSTALL_DIR/heartbeat.sh

[Install]
WantedBy=default.target
SVC
  cat > "$HOME/.config/systemd/user/kaditech-fabric-heartbeat.timer" <<TMR
[Unit]
Description=Kaditech Fabric heartbeat every 45s

[Timer]
OnBootSec=20
OnUnitActiveSec=45
AccuracySec=5

[Install]
WantedBy=timers.target
TMR
  if command -v systemctl >/dev/null && systemctl --user list-unit-files >/dev/null 2>&1; then
    systemctl --user daemon-reload || true
    systemctl --user enable --now kaditech-fabric-heartbeat.timer || true
    log "User timer enabled: kaditech-fabric-heartbeat.timer"
  else
    log "No user systemd — run heartbeat via cron: */1 * * * * $INSTALL_DIR/heartbeat.sh"
  fi
}

main() {
  consent
  register_once
  install_heartbeat
  install_wg_if_present "${1:-}"
  log "Fabric Linux client installed. Version $VERSION"
  echo
  echo "Done. Heartbeat running. For LAN: place admin-issued wg-client.conf next to install.sh and re-run: $0 /path/to/wg-client.conf"
}
main "$@"
