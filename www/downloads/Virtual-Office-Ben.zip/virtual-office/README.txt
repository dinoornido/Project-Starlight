Kaditech Virtual Office + Tech Fabric (Ben)
==========================================

SonicWall SSL VPN rejecting your password is SEPARATE from tech Fabric.
We are NOT using new SonicWall SSL VPN logins for this path.

TECH FABRIC PATH (this is the fix):
  1) Install WireGuard for Windows:
     https://www.wireguard.com/install/
  2) Import:  wg-client.conf  (in this folder)  as a tunnel
  3) Click Activate (status should show recent handshake)
  4) Open SysAide:  http://192.168.1.101:8080
     Or run: Open-Office.cmd
  5) Run Fabric Client v1.4 (Run-Client.cmd) while tunnel is ON
     Registry should reach http://10.8.0.1:3055 or 192.168.1.198

If WireGuard cannot connect (no handshake): office firewall must allow
UDP 51820 to the lab (team will open on SonicWall). Tell Betty.

Your Fabric node name: win-beastmachine-cheap
