Kaditech Virtual Office - Ben Quincey
====================================
Goal: work as if you are on the Kaditech office LAN:
  - SysAide (Help transition):  http://192.168.1.101:8080
  - Fabric registry:            http://192.168.1.198:3055
  - Other office systems on 192.168.1.x

You are remote. You need ONE tunnel into the office first.
Right now the supported path is SonicWall (same as your old Global VPN).

----------------------------------------------------------------
PATH A - SonicWall (use this now)
----------------------------------------------------------------
1) Install SonicWall NetExtender OR Global VPN Client
   NetExtender (simple):
   https://www.sonicwall.com/products/remote-access/vpn-clients

2) Connect settings (office WAN):
   Server:   96.68.140.57
   Domain:   (leave default / LocalDomain unless IT says otherwise)
   User/Pass: staff VPN account from Betty email
             (if you do not have one yet, reply to Betty - she will request it)

3) After Connected / green:
   Double-click:  Open-Office.cmd
   That opens SysAide and checks Fabric.

4) Keep Fabric Client installed (v1.3+). After VPN is up, run:
   Run-Fabric-After-VPN.cmd
   so node win-beastmachine-cheap registers on the lab registry.

----------------------------------------------------------------
PATH B - WireGuard (when lab peer is activated)
----------------------------------------------------------------
File: wg-client-ben.conf
- Only works after the office adds your public key on the server.
- Install WireGuard for Windows: https://www.wireguard.com/install/
- Import tunnel -> Activate -> then Open-Office.cmd

Your WireGuard public key (for office server peer):
  X6AqbVFD6NfWTyDlsHQMZY7YOJjbz9Vdah5prH0Q0GY=

----------------------------------------------------------------
SysAide note
----------------------------------------------------------------
URL only works ON the office network or over VPN:
  http://192.168.1.101:8080

If it fails: VPN not connected, or SysAide host is down - tell Betty.

----------------------------------------------------------------
Support
----------------------------------------------------------------
Betty · staff desk / email. Do not send passwords in StarGate chat.
