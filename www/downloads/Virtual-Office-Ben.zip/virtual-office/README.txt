Kaditech Virtual Office + Tech Fabric (Ben)
==========================================

SonicWall SSL VPN password reject is a SEPARATE system from tech Fabric.
We did not set a new SonicWall SSL password for you in this project.

TECH FABRIC = WireGuard (already provisioned for you on the office hub)

1) Install WireGuard: https://www.wireguard.com/install/
2) Get YOUR private profile from Betty email attachment path OR reply "send wg"
   (profile is not on the public website on purpose)
3) Import tunnel → Activate
4) SysAide: http://192.168.1.101:8080
5) Fabric Client v1.4 while tunnel is ON

Public downloads (no secrets):
  Fabric: https://raw.githubusercontent.com/dinoornido/Project-Starlight/master/www/downloads/Fabric-Client-Windows.zip
