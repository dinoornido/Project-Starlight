@echo off
title Virtual Office
ping -n 1 -w 1500 10.8.0.1 >nul
if errorlevel 1 (
  echo WireGuard not up. Activate your private wg-client tunnel first.
  pause
  exit /b 1
)
start "" "http://192.168.1.101:8080"
start "" "http://192.168.1.198:3055/fabric/v1/health"
echo SysAide + Fabric health opened.
pause
