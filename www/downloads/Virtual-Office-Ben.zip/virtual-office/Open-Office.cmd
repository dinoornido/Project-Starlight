@echo off
title Virtual Office
echo Checking WireGuard office path...
ping -n 1 -w 1500 10.8.0.1 >nul
if errorlevel 1 (
  echo WireGuard not up yet. Activate wg-client tunnel first.
  echo Then run this again.
  pause
  exit /b 1
)
echo OK hub 10.8.0.1
start "" "http://192.168.1.101:8080"
start "" "http://192.168.1.198:3055/fabric/v1/health"
echo Opened SysAide + Fabric health. Keep WireGuard ON.
pause
