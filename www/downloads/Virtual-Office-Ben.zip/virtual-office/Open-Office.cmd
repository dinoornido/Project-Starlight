@echo off
setlocal
title Kaditech Virtual Office
color 0B
echo.
echo ============================================================
echo   KADITECH VIRTUAL OFFICE
echo   SysAide + Fabric checks (as if you are in the office)
echo ============================================================
echo.

echo [1] Testing office LAN reachability...
ping -n 1 -w 1500 192.168.1.101 >nul
if errorlevel 1 (
  echo   FAIL: cannot reach 192.168.1.101
  echo   Connect SonicWall VPN first (server 96.68.140.57), then run this again.
  echo.
  goto END
)
echo   OK: 192.168.1.101 responds

echo [2] Testing Fabric lab host...
ping -n 1 -w 1500 192.168.1.198 >nul
if errorlevel 1 (
  echo   WARN: 192.168.1.198 not pinging - Fabric registry may still work on port
) else (
  echo   OK: 192.168.1.198 responds
)

echo [3] Opening SysAide...
start "" "http://192.168.1.101:8080"

echo [4] Probing Fabric health (browser optional)...
start "" "http://192.168.1.198:3055/fabric/v1/health"

echo.
echo If SysAide loaded, you are "in the office" virtually.
echo Next: Run-Fabric-After-VPN.cmd
echo.
:END
echo Press any key to close...
pause >nul
endlocal
