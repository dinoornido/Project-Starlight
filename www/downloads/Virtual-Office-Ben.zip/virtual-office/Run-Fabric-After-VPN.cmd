@echo off
setlocal
title Fabric register after VPN
cd /d "%~dp0"
color 0A
echo.
echo Re-running Fabric client so it can reach the office registry...
echo.

REM Prefer already-installed client under ProgramData if present
set "INST=%ProgramData%\Kaditech\FabricClient"
if exist "%~dp0..\Fabric-Client-Windows\fabric-client\Run-Client.cmd" (
  call "%~dp0..\Fabric-Client-Windows\fabric-client\Run-Client.cmd"
  goto END
)

REM Same folder layout if user extracted office kit beside fabric-client
if exist "%~dp0fabric-client\Run-Client.cmd" (
  call "%~dp0fabric-client\Run-Client.cmd"
  goto END
)

REM Try re-download path message
echo Fabric Run-Client.cmd not found next to this kit.
echo 1) Unzip Fabric-Client-Windows v1.3
echo 2) Copy wg-client.conf into that fabric-client folder
echo 3) Run Run-Client.cmd while VPN is connected
echo.
echo Or install from:
echo https://raw.githubusercontent.com/dinoornido/Project-Starlight/master/www/downloads/Fabric-Client-Windows.zip
echo.
:END
pause
endlocal
