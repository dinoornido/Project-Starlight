@echo off
setlocal
title Kaditech Office Tunnel (Fabric + SysAide)
color 0B
echo.
echo ============================================================
echo  KADITECH TECH FABRIC TUNNEL
echo  Uses open office port 22198 (SonicWall UDP WireGuard still closed)
echo ============================================================
echo.

set "KEY=%USERPROFILE%\.ssh\benfabric_tunnel"
if not exist "%KEY%" (
  echo Missing key: %KEY%
  echo 1) Download key from Betty email link
  echo 2) Save as that path exactly
  echo 3) Run this again
  pause
  exit /b 1
)

where ssh >nul 2>&1
if errorlevel 1 (
  echo OpenSSH client not found. Install "OpenSSH Client" in Windows Optional Features.
  pause
  exit /b 1
)

echo Starting tunnel (leave this window OPEN)...
echo   SysAide:  http://127.0.0.1:18080
echo   Fabric:   http://127.0.0.1:13055/fabric/v1/health
echo.
start "" "http://127.0.0.1:18080"

ssh -N -i "%KEY%" -p 22198 -o StrictHostKeyChecking=accept-new ^
  -L 18080:192.168.1.101:8080 -L 13055:127.0.0.1:3055 ^
  benfabric@96.68.140.57

echo Tunnel closed.
pause
