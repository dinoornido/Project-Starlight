Kaditech — Ben office tunnel (WORKING PATH)
==========================================

Problem:
  WireGuard UDP 51820 is blocked on OUR office firewall (SonicWall).
  SonicWall admin password is not available to automation — cannot open it yet.
  Ben does not need to change anything at his house for this path.

Solution (already tested from outside):
  SSH tunnel on already-open port 22198 → SysAide + Fabric lab.

Steps:
  1) Download private key (Betty link) → save as:
       %USERPROFILE%\.ssh\benfabric_tunnel
  2) Run Connect-Office-Tunnel.cmd (keep window open)
  3) SysAide opens: http://127.0.0.1:18080  (= office 192.168.1.101:8080)
  4) Run Fabric with -Registry http://127.0.0.1:13055
     or Run-Fabric-On-Tunnel.cmd

Token key URL is only in Betty email (not public website).
