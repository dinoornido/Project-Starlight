@echo off
title Fabric on tunnel
echo Make sure Connect-Office-Tunnel.cmd is running first.
echo Registry will be: http://127.0.0.1:13055
echo.
cd /d "%~dp0"
if exist "Fabric-Client.ps1" (
  powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Fabric-Client.ps1" -Registry "http://127.0.0.1:13055" -UnattendedConsent
) else if exist "%USERPROFILE%\Downloads\Fabric-Client-Windows\fabric-client\Fabric-Client.ps1" (
  powershell -NoProfile -ExecutionPolicy Bypass -File "%USERPROFILE%\Downloads\Fabric-Client-Windows\fabric-client\Fabric-Client.ps1" -Registry "http://127.0.0.1:13055"
) else (
  echo Place this next to Fabric-Client.ps1 or install Fabric client first.
)
pause
